# hackbar2.1.3
firefox hackbar收费前的残留版本</br>
使用方法</br>
打开firefox的插件目录</br>
![Image text](https://github.com/HCTYMFF/hackbar2.1.3/blob/master/img/1.png)

然后点这里
</br>
![Image text](https://github.com/HCTYMFF/hackbar2.1.3/blob/master/img/2.png)
</br>
加载{4c98c9c7-fc13-4622-b08a-a18923469c1c}.xpi  即可


---------------------------------------------------------------------------
应广大网友要求，新增Chrome版的Hackbar破解版。使用方法:正常安装插件即可。

![Image text](https://github.com/HCTYMFF/hackbar2.1.3/blob/master/img/111.png)






